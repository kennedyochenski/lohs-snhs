# LOHS SNHS website prototype (GitHub Pages)

## Publish the prototype
1. Sign in to https://github.com/ or create a free account.
2. Click **New repository**.
3. Name it `lohs-snhs`, set it to **Public**, and create the repository.
4. Click **Add file → Upload files** and upload `index.html` from this folder.
5. Click **Commit changes**.
6. Open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then click **Save**.
8. Wait for GitHub Pages to publish. The address will be similar to `https://YOUR-USERNAME.github.io/lohs-snhs/`.

## Important limitations
This is a static HTML prototype. Its records are stored in the current browser's local storage, so students on different devices will NOT share a roster or submissions. The advisor password is present in the client-side JavaScript and is not secure authentication. Do not use this public prototype for real student records, attendance, contact information, or payment records. A shared live system needs a database and server-side authentication (and should follow school privacy requirements).
